package com.example.flix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminFlixApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminFlixApplication.class, args);
	}

}
