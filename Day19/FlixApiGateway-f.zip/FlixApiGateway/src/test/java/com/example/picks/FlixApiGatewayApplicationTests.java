package com.example.picks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlixApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
